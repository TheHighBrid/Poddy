#!/usr/bin/env python3
"""
LocalPod
Document -> source notes -> two-host dialogue -> Kokoro TTS -> MP3

Designed for Android/Termux.
No paid API keys.
"""

from __future__ import annotations

import argparse
import array
import html
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import textwrap
import wave
import zipfile
import xml.etree.ElementTree as ET

ROOT = Path.home() / ".local" / "share" / "localpod"
KOKORO = ROOT / "models" / "kokoro-en-v0_19"
DEFAULT_MODEL = "Qwen/Qwen3-4B-GGUF:Q4_K_M"

VOICE_NAMES = {
    0: "af",
    1: "af_bella",
    2: "af_nicole",
    3: "af_sarah",
    4: "af_sky",
    5: "am_adam",
    6: "am_michael",
    7: "bf_emma",
    8: "bf_isabella",
    9: "bm_george",
    10: "bm_lewis",
}


class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []

    def handle_data(self, data):
        if data.strip():
            self.parts.append(data.strip())

    def text(self):
        return "\n".join(self.parts)


def run(cmd, *, input_text=None, check=True, cwd=None, timeout=None):
    p = subprocess.run(
        cmd,
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd,
        timeout=timeout,
    )
    if check and p.returncode != 0:
        raise RuntimeError(
            f"Command failed ({p.returncode}): {' '.join(map(str, cmd))}\n"
            f"{p.stderr[-4000:]}"
        )
    return p


def require(cmd):
    if shutil.which(cmd) is None:
        raise SystemExit(f"Missing required command: {cmd}. Run install.sh first.")


def normalize_text(s: str) -> str:
    s = s.replace("\x00", " ")
    s = re.sub(r"\r\n?", "\n", s)
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


def extract_docx(path: Path) -> str:
    with zipfile.ZipFile(path) as z:
        xml_bytes = z.read("word/document.xml")
    root = ET.fromstring(xml_bytes)
    texts = []
    for elem in root.iter():
        if elem.tag.endswith("}t") and elem.text:
            texts.append(elem.text)
        elif elem.tag.endswith("}p"):
            texts.append("\n")
    return normalize_text(" ".join(texts).replace(" \n ", "\n"))


def extract_text(path: Path) -> str:
    suffix = path.suffix.lower()

    if suffix == ".pdf":
        require("pdftotext")
        p = run(["pdftotext", "-layout", str(path), "-"])
        text = p.stdout
    elif suffix == ".docx":
        text = extract_docx(path)
    elif suffix in {".txt", ".md", ".rst", ".csv", ".json"}:
        text = path.read_text(encoding="utf-8", errors="ignore")
    elif suffix in {".html", ".htm"}:
        parser = TextExtractor()
        parser.feed(path.read_text(encoding="utf-8", errors="ignore"))
        text = parser.text()
    else:
        raise SystemExit(
            f"Unsupported document type: {suffix or '(none)'}\n"
            "Supported: PDF, DOCX, TXT, MD, RST, CSV, JSON, HTML."
        )

    text = normalize_text(text)
    if len(text) < 200:
        raise SystemExit(
            "The document produced too little readable text. "
            "If this is a scanned PDF, OCR it first."
        )
    return text


def chunk_text(text: str, max_chars=12000, max_chunks=16):
    paras = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    chunks, current = [], []
    n = 0

    for p in paras:
        if n + len(p) + 2 > max_chars and current:
            chunks.append("\n\n".join(current))
            current, n = [], 0
        current.append(p)
        n += len(p) + 2

    if current:
        chunks.append("\n\n".join(current))

    if len(chunks) <= max_chunks:
        return chunks

    # Sample evenly across very large documents rather than silently reading only the start.
    idx = []
    for i in range(max_chunks):
        pos = round(i * (len(chunks) - 1) / (max_chunks - 1))
        if pos not in idx:
            idx.append(pos)
    return [chunks[i] for i in idx]


def clean_llm_output(s: str) -> str:
    s = re.sub(r"<think>.*?</think>", "", s, flags=re.S | re.I)
    return s.strip()


def llama(prompt: str, *, tokens=1600, temp=0.45, model=DEFAULT_MODEL) -> str:
    require("llama-cli")
    cmd = [
        "llama-cli",
        "-hf", model,
        "-c", "16384",
        "-n", str(tokens),
        "--temp", str(temp),
        "-p", prompt,
    ]
    p = run(cmd, timeout=None)
    if not p.stdout.strip():
        raise RuntimeError(f"llama-cli returned no text.\n{p.stderr[-3000:]}")
    return clean_llm_output(p.stdout)


def distill_chunk(chunk: str, index: int, total: int, model: str) -> str:
    prompt = f"""
/no_think
You are a research editor preparing evidence for a short spoken podcast.

SOURCE EXCERPT {index}/{total}
----------------
{chunk}
----------------

Return compact factual notes only. Preserve:
- central claims and conclusions
- concrete numbers, dates, names, mechanisms, findings, and examples
- disagreements, caveats, and uncertainty
- surprising or counterintuitive details worth discussing

Do not invent anything. Do not write a podcast script yet.
Aim for 350-550 words.
"""
    return llama(prompt, tokens=900, temp=0.2, model=model)


def parse_json_array(raw: str):
    raw = clean_llm_output(raw)
    starts = [m.start() for m in re.finditer(r"\[", raw)]
    for start in starts:
        end = raw.rfind("]")
        if end <= start:
            continue
        candidate = raw[start:end + 1]
        try:
            data = json.loads(candidate)
            if isinstance(data, list):
                return data
        except json.JSONDecodeError:
            pass
    return None


def parse_dialogue_fallback(raw: str):
    turns = []
    for line in raw.splitlines():
        m = re.match(r"^\s*(?:HOST\s*)?([AB])\s*[:\-]\s*(.+)$", line, flags=re.I)
        if m:
            turns.append({"host": m.group(1).upper(), "text": m.group(2).strip()})
    return turns


def generate_dialogue(notes: str, minutes: int, title: str | None, model: str):
    words = int(minutes * 145)
    episode_title = title or "Deep Dive"
    prompt = f"""
/no_think
Create a polished two-host research podcast from the evidence below.

EPISODE TITLE: {episode_title}
TARGET LENGTH: about {minutes} minutes, approximately {words} spoken words.

HOST DYNAMIC
- Host A is curious, precise, and good at asking the question a smart listener would ask.
- Host B is analytical, vivid, and good at explaining mechanisms and implications.
- Both are natural adults. No fake radio hype, no corporate cheerleading, no repetitive "absolutely".
- They can gently challenge each other, clarify ambiguity, and connect ideas.
- Use occasional short reactions, but prioritize substance.
- Open immediately with an intriguing finding or tension.
- End with a concise synthesis, not a generic call to action.
- Never claim facts absent from the evidence.
- Make uncertainty explicit where the notes are uncertain.

EVIDENCE
--------
{notes}
--------

OUTPUT REQUIREMENT
Return ONLY valid JSON, no markdown:
[
  {{"host":"A","text":"..."}},
  {{"host":"B","text":"..."}}
]

Use 14-30 turns. Keep each turn comfortably speakable.
"""
    raw = llama(prompt, tokens=max(2400, int(words * 1.7)), temp=0.65, model=model)
    data = parse_json_array(raw) or parse_dialogue_fallback(raw)

    if not data:
        repair = f"""
/no_think
Convert the material below into ONLY a valid JSON array of podcast turns.
Every item must have exactly "host" ("A" or "B") and "text".
No markdown, comments, or extra keys.

MATERIAL:
{raw}
"""
        repaired = llama(repair, tokens=max(2200, int(words * 1.4)), temp=0.1, model=model)
        data = parse_json_array(repaired)

    if not data:
        raise RuntimeError("Could not parse the generated dialogue.")

    cleaned = []
    for item in data:
        if not isinstance(item, dict):
            continue
        host = str(item.get("host", "")).upper().strip()
        text = normalize_text(str(item.get("text", "")))
        if host in {"A", "B"} and text:
            cleaned.append({"host": host, "text": text})

    if len(cleaned) < 4:
        raise RuntimeError("Generated dialogue was unexpectedly short.")

    return cleaned


def load_tts():
    try:
        import sherpa_onnx
    except Exception as e:
        raise SystemExit(f"Could not import sherpa_onnx: {e}\nRun install.sh again.")

    required = ["model.onnx", "voices.bin", "tokens.txt", "espeak-ng-data"]
    missing = [x for x in required if not (KOKORO / x).exists()]
    if missing:
        raise SystemExit(f"Kokoro model is incomplete. Missing: {', '.join(missing)}")

    config = sherpa_onnx.OfflineTtsConfig(
        model=sherpa_onnx.OfflineTtsModelConfig(
            kokoro=sherpa_onnx.OfflineTtsKokoroModelConfig(
                model=str(KOKORO / "model.onnx"),
                voices=str(KOKORO / "voices.bin"),
                tokens=str(KOKORO / "tokens.txt"),
                data_dir=str(KOKORO / "espeak-ng-data"),
            ),
            num_threads=max(2, min(6, os.cpu_count() or 4)),
            debug=False,
        ),
        max_num_sentences=1,
    )
    return sherpa_onnx.OfflineTts(config)


def save_audio_wav(audio, out: Path):
    # sherpa returns float samples in [-1, 1]. Avoid an extra soundfile dependency.
    samples = array.array(
        "h",
        (
            max(-32768, min(32767, int(float(x) * 32767.0)))
            for x in audio.samples
        ),
    )
    with wave.open(str(out), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(int(audio.sample_rate))
        wf.writeframes(samples.tobytes())


def create_silence(out: Path, sample_rate: int, ms=260):
    frames = int(sample_rate * ms / 1000)
    with wave.open(str(out), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(b"\x00\x00" * frames)


def synthesize(dialogue, out_dir: Path, voice_a: int, voice_b: int, speed: float):
    require("ffmpeg")
    tts = load_tts()
    seg_dir = out_dir / "segments"
    seg_dir.mkdir(parents=True, exist_ok=True)

    concat_items = []
    silence_path = None
    detected_sr = None

    for i, turn in enumerate(dialogue, 1):
        sid = voice_a if turn["host"] == "A" else voice_b
        print(f"  voice {i:02d}/{len(dialogue)} | Host {turn['host']} | {VOICE_NAMES.get(sid, sid)}")
        audio = tts.generate(turn["text"], sid=sid, speed=speed)
        wav_path = seg_dir / f"{i:03d}_{turn['host']}.wav"
        save_audio_wav(audio, wav_path)
        concat_items.append(wav_path)

        if detected_sr is None:
            detected_sr = int(audio.sample_rate)
            silence_path = seg_dir / "_pause.wav"
            create_silence(silence_path, detected_sr, ms=280)
        concat_items.append(silence_path)

    concat_file = seg_dir / "concat.txt"
    with concat_file.open("w", encoding="utf-8") as f:
        for item in concat_items:
            escaped = str(item).replace("'", r"'\''")
            f.write(f"file '{escaped}'\n")

    wav_full = out_dir / "episode.wav"
    mp3_full = out_dir / "episode.mp3"

    run([
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
        "-f", "concat", "-safe", "0", "-i", str(concat_file),
        "-c:a", "pcm_s16le",
        str(wav_full),
    ])

    run([
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
        "-i", str(wav_full),
        "-af", "loudnorm=I=-16:TP=-1.5:LRA=11",
        "-codec:a", "libmp3lame", "-b:a", "128k",
        str(mp3_full),
    ])

    return mp3_full


def main():
    ap = argparse.ArgumentParser(
        prog="podcastify",
        description="Turn a document into a two-host local AI podcast."
    )
    ap.add_argument("document", type=Path)
    ap.add_argument("--minutes", type=int, default=7, choices=range(3, 16), metavar="3-15")
    ap.add_argument("--title", default=None)
    ap.add_argument("--voice-a", type=int, default=3, choices=range(0, 11))
    ap.add_argument("--voice-b", type=int, default=6, choices=range(0, 11))
    ap.add_argument("--speed", type=float, default=1.02)
    ap.add_argument("--model", default=DEFAULT_MODEL)
    ap.add_argument("--output", type=Path, default=None)
    ap.add_argument("--keep-wav", action="store_true")
    ap.add_argument("--list-voices", action="store_true")
    args = ap.parse_args()

    if args.list_voices:
        for sid, name in VOICE_NAMES.items():
            print(f"{sid:2}: {name}")
        return

    doc = args.document.expanduser().resolve()
    if not doc.exists():
        raise SystemExit(f"File not found: {doc}")

    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", doc.stem).strip("_") or "podcast"
    out_dir = (args.output or (Path.cwd() / f"{stem}_podcast")).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    print("1/4 Reading document...")
    text = extract_text(doc)
    chunks = chunk_text(text)
    print(f"    {len(text):,} characters, {len(chunks)} research chunk(s)")

    print("2/4 Distilling research locally...")
    notes = []
    for i, chunk in enumerate(chunks, 1):
        print(f"    chunk {i}/{len(chunks)}")
        notes.append(distill_chunk(chunk, i, len(chunks), args.model))
    notes_text = "\n\n".join(
        f"### EXCERPT {i}\n{x}" for i, x in enumerate(notes, 1)
    )
    (out_dir / "research_notes.txt").write_text(notes_text, encoding="utf-8")

    print("3/4 Writing two-host episode...")
    dialogue = generate_dialogue(notes_text, args.minutes, args.title, args.model)
    (out_dir / "dialogue.json").write_text(
        json.dumps(dialogue, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    transcript = "\n\n".join(
        f"HOST {x['host']}: {x['text']}" for x in dialogue
    )
    (out_dir / "transcript.txt").write_text(transcript, encoding="utf-8")
    print(f"    {len(dialogue)} turns")

    print("4/4 Synthesizing Kokoro voices...")
    mp3 = synthesize(
        dialogue,
        out_dir,
        voice_a=args.voice_a,
        voice_b=args.voice_b,
        speed=args.speed,
    )

    wav = out_dir / "episode.wav"
    if wav.exists() and not args.keep_wav:
        wav.unlink()

    print()
    print("DONE")
    print(f"MP3:        {mp3}")
    print(f"Transcript: {out_dir / 'transcript.txt'}")
    print(f"Dialogue:   {out_dir / 'dialogue.json'}")
    print(f"Notes:      {out_dir / 'research_notes.txt'}")


if __name__ == "__main__":
    main()
