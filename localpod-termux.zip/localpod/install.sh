#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

ROOT="$HOME/.local/share/localpod"
BIN="$HOME/.local/bin"
VENV="$ROOT/venv"
MODEL_DIR="$ROOT/models/kokoro-en-v0_19"
REPO_DIR="$ROOT/src/sherpa-onnx"

echo "== LocalPod: Termux installer =="

if ! command -v pkg >/dev/null 2>&1; then
  echo "ERROR: This installer is for Termux."
  exit 1
fi

pkg update -y
pkg install -y \
  python python-numpy \
  ffmpeg poppler \
  git curl wget bzip2 \
  clang cmake make ninja \
  llama-cpp

mkdir -p "$ROOT" "$BIN" "$ROOT/models" "$ROOT/src"

# Use Termux's packaged NumPy inside the venv to avoid compiling NumPy on Android.
if [ ! -d "$VENV" ]; then
  python -m venv --system-site-packages "$VENV"
fi

"$VENV/bin/python" -m pip install --upgrade pip setuptools wheel

echo
echo "Installing sherpa-onnx Python support..."
if ! "$VENV/bin/python" -m pip install --upgrade sherpa-onnx sherpa-onnx-bin; then
  echo
  echo "Prebuilt Python package was unavailable. Building sherpa-onnx from current source..."
  rm -rf "$REPO_DIR"
  git clone --depth 1 https://github.com/k2-fsa/sherpa-onnx.git "$REPO_DIR"
  (
    cd "$REPO_DIR"
    "$VENV/bin/python" -m pip install .
  )
fi

echo
echo "Downloading Kokoro English voice model..."
if [ ! -f "$MODEL_DIR/model.onnx" ]; then
  cd "$ROOT/models"
  curl -fL \
    https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-en-v0_19.tar.bz2 \
    -o kokoro-en-v0_19.tar.bz2
  tar -xjf kokoro-en-v0_19.tar.bz2
  rm -f kokoro-en-v0_19.tar.bz2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp "$SCRIPT_DIR/podcastify.py" "$ROOT/podcastify.py"
chmod +x "$ROOT/podcastify.py"

cat > "$BIN/podcastify" <<EOF
#!/data/data/com.termux/files/usr/bin/bash
exec "$VENV/bin/python" "$ROOT/podcastify.py" "\$@"
EOF
chmod +x "$BIN/podcastify"

case ":$PATH:" in
  *":$BIN:"*) ;;
  *)
    echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
    export PATH="$BIN:$PATH"
    ;;
esac

echo
echo "Verifying..."
command -v llama-cli >/dev/null 2>&1 || {
  echo "ERROR: llama-cli was not installed correctly."
  exit 1
}

"$VENV/bin/python" - <<'PY'
import sherpa_onnx
print("sherpa-onnx:", getattr(sherpa_onnx, "__version__", "installed"))
PY

test -f "$MODEL_DIR/model.onnx"
test -f "$MODEL_DIR/voices.bin"
test -f "$MODEL_DIR/tokens.txt"

echo
echo "Installation complete."
echo
echo "First use:"
echo '  podcastify "/sdcard/Download/report.pdf"'
echo
echo "The first podcast generation downloads Qwen3-4B Q4_K_M through llama.cpp."
echo "After that, generation can run locally/offline."
