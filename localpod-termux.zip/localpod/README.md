# LocalPod for Termux

A no-subscription document-to-podcast pipeline for Android/Termux.

## What it does

PDF / DOCX / TXT / Markdown / HTML
→ local source extraction
→ local Qwen3 research distillation through llama.cpp
→ natural two-host script
→ two Kokoro voices through sherpa-onnx
→ normalized MP3 + transcript + JSON + research notes

No paid API key is required.

## Install

Unzip this folder in Termux, then:

```bash
cd /path/to/localpod
chmod +x install.sh
./install.sh
source ~/.bashrc
```

The installer uses:
- Termux `llama-cpp`
- Qwen3-4B GGUF for local writing
- sherpa-onnx
- Kokoro English TTS
- ffmpeg
- poppler/pdftotext

The Qwen model is downloaded automatically by llama.cpp the first time `podcastify`
runs. Subsequent generations can run locally.

## Generate a podcast

```bash
podcastify "/sdcard/Download/research.pdf"
```

Seven minutes is the default.

```bash
podcastify "/sdcard/Download/research.pdf" --minutes 10 --title "The Andalusian Synthesis"
```

## Voice defaults

Host A: `af_sarah` (ID 3)
Host B: `am_michael` (ID 6)

Show all bundled Kokoro voices:

```bash
podcastify dummy --list-voices
```

Choose two:

```bash
podcastify report.pdf --voice-a 7 --voice-b 10
```

Available IDs:

- 0 af
- 1 af_bella
- 2 af_nicole
- 3 af_sarah
- 4 af_sky
- 5 am_adam
- 6 am_michael
- 7 bf_emma
- 8 bf_isabella
- 9 bm_george
- 10 bm_lewis

## Output

A run creates a folder such as:

```text
research_podcast/
├── episode.mp3
├── transcript.txt
├── dialogue.json
├── research_notes.txt
└── segments/
```

## Notes

- Scanned/image-only PDFs need OCR before this tool can read them.
- Very large documents are sampled evenly across up to 16 research chunks to keep
  generation practical on a phone/tablet.
- The first generation needs internet to fetch the Qwen GGUF if it is not cached.
- Kokoro and the document content run locally after installation.
- If you prefer a different local GGUF, pass its Hugging Face llama.cpp spec with
  `--model`.
